export type ImportRow = {
  quantity: number;
  unitCost: number;
  shippingCost: number;
  taxCost: number;
};

export type SaleRow = {
  quantity: number;
  unitPrice: number;
  discount: number;
  otherCost: number;
};

export function importTotal(x: ImportRow) {
  return x.quantity * x.unitCost + x.shippingCost + x.taxCost;
}

export function saleRevenue(x: SaleRow) {
  return x.quantity * x.unitPrice - x.discount;
}

export function saleCost(x: SaleRow, estimatedUnitCost: number) {
  return x.quantity * estimatedUnitCost + x.otherCost;
}

export function grossProfit(revenue: number, cost: number) {
  return revenue - cost;
}

export function margin(revenue: number, profit: number) {
  return revenue === 0 ? 0 : (profit / revenue) * 100;
}