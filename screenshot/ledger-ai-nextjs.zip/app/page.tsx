"use client";

import { useEffect, useState } from "react";

type Summary = {
  imports: { count: number; total: number; quantity: number };
  sales: { count: number; revenue: number; quantity: number };
  estimatedCOGS: number;
  estimatedProfit: number;
  estimatedMarginPct: number;
  products: { product: string; revenue: number; quantity: number }[];
};

export default function Home() {
  const [summary, setSummary] = useState<Summary | null>(null);
  const [tips, setTips] = useState<any>(null);
  const [busy, setBusy] = useState(false);

  async function refresh() {
    const r = await fetch("/api/analytics", { cache: "no-store" });
    const d = await r.json();
    setSummary(d.summary); setTips(d.tips);
  }
  useEffect(() => { refresh(); }, []);

  async function add(kind: "imports" | "sales") {
    const product = prompt("Product");
    if (!product) return;
    const quantity = Number(prompt("Quantity", "1"));
    const price = Number(prompt(kind === "sales" ? "Unit selling price" : "Unit import cost", "0"));
    if (!quantity || price < 0) return;
    setBusy(true);
    await fetch(`/api/${kind}`, {
      method: "POST", headers: { "Content-Type": "application/json" },
      body: JSON.stringify(kind === "sales"
        ? { date: new Date(), product, quantity, unitPrice: price, discount: 0, otherCost: 0 }
        : { date: new Date(), supplier: "Manual", product, quantity, unitCost: price, shippingCost: 0, taxCost: 0 })
    });
    await refresh(); setBusy(false);
  }

  const money = (n: number) => new Intl.NumberFormat(undefined, { style: "currency", currency: "USD" }).format(n);

  return (
    <main>
      <header><h1>Ledger AI</h1><p>Import + sales ledger, profit analysis and AI sales tips.</p></header>
      <section className="actions">
        <button onClick={() => add("imports")} disabled={busy}>＋ Import</button>
        <button onClick={() => add("sales")} disabled={busy}>＋ Sale</button>
        <button onClick={refresh} disabled={busy}>↻ Analyze</button>
      </section>
      {summary && <section className="grid">
        <Card title="Sales revenue" value={money(summary.sales.revenue)} />
        <Card title="Estimated profit" value={money(summary.estimatedProfit)} />
        <Card title="Margin" value={`${summary.estimatedMarginPct.toFixed(1)}%`} />
        <Card title="Imported quantity" value={summary.imports.quantity.toFixed(2)} />
      </section>}
      {summary && <section className="panel">
        <h2>Products</h2>
        <table><thead><tr><th>Product</th><th>Units</th><th>Revenue</th></tr></thead>
          <tbody>{summary.products.map(p => <tr key={p.product}><td>{p.product}</td><td>{p.quantity}</td><td>{money(p.revenue)}</td></tr>)}</tbody>
        </table>
      </section>}
      {tips && <section className="panel">
        <h2>AI sales tips</h2>
        <p>{tips.summary}</p>
        <h3>Opportunities</h3><ul>{(tips.opportunities ?? []).map((x: string, i: number) => <li key={i}>{x}</li>)}</ul>
        <h3>Risks</h3><ul>{(tips.risks ?? []).map((x: string, i: number) => <li key={i}>{x}</li>)}</ul>
        <h3>Recommended actions</h3><ul>{(tips.actions ?? []).map((x: string, i: number) => <li key={i}>{x}</li>)}</ul>
        <h3>Forecast</h3><pre>{JSON.stringify(tips.forecast ?? [], null, 2)}</pre>
      </section>}
    </main>
  );
}

function Card({ title, value }: { title: string; value: string }) {
  return <div className="card"><span>{title}</span><strong>{value}</strong></div>;
}