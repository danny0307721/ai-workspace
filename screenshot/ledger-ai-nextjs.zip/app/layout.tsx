import "./globals.css";
import type { Metadata } from "next";

export const metadata: Metadata = {
  title: "Ledger AI",
  description: "Import and sales ledger with AI analysis"
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return <html lang="en"><body>{children}</body></html>;
}