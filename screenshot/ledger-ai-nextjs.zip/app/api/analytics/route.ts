import { db } from "@/lib/db";
import { generateSalesTips } from "@/lib/llm";

export async function GET() {
  const [imports, sales] = await Promise.all([
    db.importEntry.findMany(),
    db.saleEntry.findMany()
  ]);

  const importTotal = imports.reduce(
    (s, x) => s + Number(x.quantity) * Number(x.unitCost) + Number(x.shippingCost) + Number(x.taxCost), 0
  );

  const revenue = sales.reduce(
    (s, x) => s + Number(x.quantity) * Number(x.unitPrice) - Number(x.discount), 0
  );

  const quantityImported = imports.reduce((s, x) => s + Number(x.quantity), 0);
  const quantitySold = sales.reduce((s, x) => s + Number(x.quantity), 0);
  const avgImportUnitCost = quantityImported ? importTotal / quantityImported : 0;
  const cogs = quantitySold * avgImportUnitCost + sales.reduce((s, x) => s + Number(x.otherCost), 0);
  const profit = revenue - cogs;

  const byProduct = new Map<string, { revenue: number; quantity: number }>();
  for (const s of sales) {
    const p = byProduct.get(s.product) ?? { revenue: 0, quantity: 0 };
    p.revenue += Number(s.quantity) * Number(s.unitPrice) - Number(s.discount);
    p.quantity += Number(s.quantity);
    byProduct.set(s.product, p);
  }

  const summary = {
    imports: { count: imports.length, total: importTotal, quantity: quantityImported },
    sales: { count: sales.length, revenue, quantity: quantitySold },
    estimatedCOGS: cogs,
    estimatedProfit: profit,
    estimatedMarginPct: revenue ? (profit / revenue) * 100 : 0,
    products: [...byProduct.entries()].map(([product, v]) => ({ product, ...v }))
      .sort((a, b) => b.revenue - a.revenue)
  };

  let tips = null;
  try { tips = await generateSalesTips({ summary }); } catch {}

  return Response.json({ summary, tips });
}