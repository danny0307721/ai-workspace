# Ledger AI

Next.js + TypeScript + PostgreSQL + Ollama starter for import/sales ledgers, profit calculation, and AI sales tips.

## Run

1. Install Node.js 20+ and Docker.
2. Copy `.env.example` to `.env`.
3. Start services:

```bash
docker compose up -d
```

4. Install packages:

```bash
npm install
npx prisma generate
npx prisma db push
```

5. Pull a local model:

```bash
docker exec -it $(docker ps -qf name=ollama) ollama pull llama3.1:8b
```

6. Start Next.js:

```bash
npm run dev
```

Open http://localhost:3000.

## Notes

The current starter estimates COGS using the average imported unit cost. For production accounting, replace that with explicit inventory valuation (FIFO/weighted-average), currency/tax rules, returns, stock adjustments, and audit trails.

The AI forecast is advisory: it consumes ledger aggregates and must not be treated as guaranteed predictions.
